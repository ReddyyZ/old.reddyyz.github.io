import logging
from colorama import init, Fore

white   = Fore.WHITE
black   = Fore.BLACK
red     = Fore.RED
reset   = Fore.RESET
blue    = Fore.BLUE
cyan    = Fore.CYAN
yellow  = Fore.YELLOW
green   = Fore.GREEN
magenta = Fore.MAGENTA

init()
logging.addLevelName(logging.CRITICAL, f"[{red}!!{reset}]")
logging.addLevelName(logging.WARNING, f"[{red}!{reset}]")
logging.addLevelName(logging.INFO, f"[{cyan}*{reset}]")
logging.addLevelName(logging.DEBUG, f"[{cyan}**{reset}]")
logging.basicConfig(format="%(levelname)s %(message)s", level=logging.DEBUG)

logging.info("ada")