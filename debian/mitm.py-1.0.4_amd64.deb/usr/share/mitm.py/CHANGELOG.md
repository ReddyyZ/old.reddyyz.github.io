# mitm.py v1.0.0

- Added ARP Poisoning attack
- Added FTP Sniffing attack
- Added HTTP Sniffing attack

---

# mitm.py v1.0.1

- Added DNS Spoofing attack

# mitm.py v1.0.2

- Added target selection on other attacks
- Added captive portal
- Added automatic target selection on ARP Poisoning

# mitm.py v1.0.3

- Added multithreading in DNS Spoofing, to respond faster
- Hidden php server output

# mitm.py v1.0.4

- Bug fixes